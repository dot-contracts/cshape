using System;
using System.IO;
using System.Data;
using System.Windows;
using System.IO.Packaging;
using Microsoft.UI.Xaml.Controls;

using nexus.common;
using nexus.common.cache;
using nexus.common.control;
using nexus.common.dal;

namespace nexus.plugins.promo
{

    public partial class HouseNo : NxPanelBase
    {

        private string currentSearch = "";

        public HouseNo()
        {
            InitializeComponent();
        }

        public void Create()
        {

        }

        #region Override

        public new bool Load(int LoadState, string Property)
        {
            return false;
        }
        public new void Reset()
        {
        }
        public new bool Save()
        {
            return false;
        }
        public new bool Process()
        {
            return false;
        }
        public new bool Execute(string Command, string Parameters)
        {
            return false;
        }


        private void Results_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //if (Results.SelectedItem is LookupResult selected)
            //{
            //    ShowResult(selected);
            //}
        }

        private void ShowSearch()
        {
            //Search.Visibility = Visibility.Visible;
            //Result.Visibility = Visibility.Collapsed;
        }

        #endregion

    }
}
